Para compilar o arquivo com a biblioteca separada usar os comandos:
 - Para criar o arquivo objeto: gcc -c arquivos.c -o objeto.o 
 - Para compilar: gcc projeto2.c objeto.o -o executavel
 - Para executar: .\executavel